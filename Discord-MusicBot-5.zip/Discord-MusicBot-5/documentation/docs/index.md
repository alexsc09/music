# Welcome to Discord-MusicBot

An advanced discord music bot, supports Spotify, Soundcloud, YouTube with Shuffling, Volume Control and Web Dashboard with Slash Commands support!

## What does this docs contains?

This docs contains how to install on servers, frequently asked questions and how to solve common problems.
